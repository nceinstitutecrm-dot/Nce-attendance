NCE ATTENDANCE - STUDENT LEAVE WHATSAPP + SMS WITH REASON
29 October 2026

FILE CONTENTS
1. index.html - Updated full NCE Attendance software
2. firestore.rules - UNCHANGED from previous Staff Attendance Save Fix ZIP
3. README_GUJARATI.txt - This installation guide

NEW FEATURE
- Save a student's leave in Student Leaves or by tapping L in Student Attendance.
- After Firebase confirms the save, a notification window opens with BOTH editable messages.
- WhatsApp and SMS are available for Parent Mobile / Student Mobile 1, 2, 3.
- Student name, From Date, To Date, Leave Reason and NCE contact numbers appear automatically.
- Existing and older Student Leave cards also have a WhatsApp & SMS button.
- Leave Reason dropdown includes 12 convenient options (legacy reasons remain supported).
- When Other is chosen, staff must enter a specific reason in the note field.
- Student profiles, leave records, fees, call records and previous Firebase data are preserved.

VERY IMPORTANT / KHAS DHYAN:
These buttons OPEN WhatsApp and the phone SMS composer with a prepared message.
They DO NOT transmit messages automatically. Press SEND in each application.
Merely opening a link does not confirm successful delivery.
True unattended automatic messaging requires approved WhatsApp Business integration
and an SMS messaging service, neither of which is included in this free HTML-only build.
Browser/phone must support SMS links; WhatsApp needs to be available for the chosen number.

INSTALL
1. Back up your old index.html + Firebase data before deploying.
2. Upload the new index.html to the SAME Netlify site.
3. Refresh browser Ctrl+Shift+R, then login.
4. Student Leaves > Add Leave > choose Student / Dates / Reason > Apply Student Leave.
5. After a successful save, choose contact, review/edit both messages and use BOTH buttons.
6. For existing leave, Student Leaves > WhatsApp & SMS button on the leave card.

SECURITY / FIRESTORE
No Firestore rules or collections were changed for this upgrade.
The included firestore.rules is a copy of the previous ZIP for your reference.
There is no need to republish rules for this messaging feature alone.
Do NOT apply allow read/write true as a workaround.

TESTING
JavaScript module syntax passed node --check.
Simulated Chromium browser tests passed desktop 1280px and mobile 390px/320px:
- both generated message links, student name / leave reason / dates
- parent number and alternate student number
- editing message updates the URL
- missing phone numbers disable links
- no horizontal scrolling on simulated form
Live Firebase, real WhatsApp/SMS delivery and actual Android WebView remain untested.
